//npm init або np, init -y
//npm install express mongoose
//npm i -D nodemon
// npm install request
// npm install express
// npm install cheerio
//npm run devconst express = require('express')
const mongoose = require('mongoose')
const path = require('path')
const exphbs = require('express-handlebars')
const todoRoutes = require('./routes/todos')

const PORT = process.env.PORT || 3000

const app = express()
const hbs = exphbs.create({
    defaultLayout: 'main',
    extname: 'hbs'
})


var request = require('request');
var cheerio = require('cheerio');


var url = "https://www.google.com.ua/search?q=%D0%BA%D0%BE%D1%82%D0%B8%D0%BA%D0%B8&sxsrf=ALeKk00qDRD8Sb02wR3XxEe__b0lbSWOOg:1587478366398&source=lnms&tbm=isch&sa=X&ved=2ahUKEwjajvjg2fnoAhVCrosKHS29BU4Q_AUoAXoECBMQAw&biw=1920&bih=940";
// var url = "https://imgur.com/search?q=cat";

var content = [];

request(url, function(err, res, body) {
  var $ = cheerio.load(body);
    $('img').each(function(i, elem) {
    	content.push($(this).attr('src'));
   });
    for (var i = 0; i<content.length; i++) {     
      console.log(content[i]);   
    }
});



app.engine('hbs', hbs.engine)
app.set('view engine', 'hbs')
app.set('views', 'views')

app.use(express.urlencoded({extended: true}))
app.use(express.static(path.join(__dirname, 'public')))

app.use(todoRoutes)

async function start() {
    try{
      await mongoose.connect(
          'mongodb+srv://Viktor:viktor2826.@cluster0-y7fp7.mongodb.net/todos',
      {
          useNewUrlParser: true,
          useFindAndModify: false
      })
      app.listen(PORT, () => {
        console.log('Server has been started...')
       })    
    } catch (e) {
     console.log(e)
    }
}

start()